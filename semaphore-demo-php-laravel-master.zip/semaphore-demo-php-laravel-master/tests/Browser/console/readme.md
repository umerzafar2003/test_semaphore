This is where the browser test log files will go.
