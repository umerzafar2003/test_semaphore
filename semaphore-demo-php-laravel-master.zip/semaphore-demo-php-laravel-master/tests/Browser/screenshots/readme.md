This is where the browser test screenshots will go.
